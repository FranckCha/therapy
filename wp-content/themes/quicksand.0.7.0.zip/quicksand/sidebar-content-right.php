<?php
/**
 * template for the right sidebar
 *
 * @package WordPress
 * @subpackage quicksand 
 */
?> 

<!--sidebar-content-right -->
<aside id="secondary" class="site-sidebar widget-area"> 
    <?php dynamic_sidebar('sidebar-content-right'); ?> 
</aside>
<!--  site-sidebar  -->