<?php
/**
 * template for the left sidebar
 *
 * @package WordPress
 * @subpackage quicksand 
 */
?>

<!--sidebar-content-right -->
<aside id="third" class="site-sidebar widget-area"> 
    <?php dynamic_sidebar('sidebar-content-left'); ?> 
</aside>
<!--  site-sidebar  -->